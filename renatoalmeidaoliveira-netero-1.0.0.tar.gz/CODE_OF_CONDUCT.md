Go Fuck Yourself
=============

Offended? Go away. We don't need people who are offended because of a stranger on the internet.  
Not offended? You're welcome to contribute.

&copy; Copyright 2015 WTFCoC Consortium Committee.
